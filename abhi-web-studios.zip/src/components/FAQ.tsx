import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Minus } from "lucide-react";

const faqs = [
  {
    question: "Do you offer maintenance after launch?",
    answer: "Yes. Every website requires ongoing maintenance to stay secure, fast, and up-to-date. We offer comprehensive maintenance and hosting packages that include regular backups, security patches, uptime monitoring, and minor content updates so you can focus on running your business."
  },
  {
    question: "How long does a typical website take?",
    answer: "Most local business and service websites are launched within 2 to 4 weeks. Complex projects with custom booking systems or extensive content may take 6 to 8 weeks. We'll provide a clear timeline during our strategy call."
  },
  {
    question: "What do I need to provide (logo, photos, content)?",
    answer: "Ideally, you'll provide your logo, brand assets, and high-quality photos of your team or location. If you don't have professional copy, we can help write SEO-optimized content based on an interview with you to ensure it captures your voice."
  },
  {
    question: "Can you redesign my existing website without losing SEO rankings?",
    answer: "Absolutely. We carefully map your existing URLs and set up proper 301 redirects to ensure you don't lose your hard-earned SEO authority. In fact, most clients see a bump in rankings due to improved site speed and mobile optimization."
  },
  {
    question: "Do you build e-commerce/booking systems?",
    answer: "Yes, we integrate robust booking systems for clinics, salons, and gyms, allowing your clients to schedule appointments 24/7. We can also build tailored e-commerce solutions for selling products, memberships, or digital services."
  },
  {
    question: "What's included in the free audit?",
    answer: "Our free website audit includes a comprehensive review of your current site's performance, mobile responsiveness, user experience (UX), and technical SEO. We'll identify what's holding you back and provide actionable steps to improve conversions."
  }
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.question,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.answer
      }
    }))
  };

  return (
    <section id="faq" className="py-16 md:py-24 lg:py-32 bg-[#FDFBF7] relative overflow-hidden border-t border-[#E4DCCB]">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-[#1F1B18] tracking-tighter mb-4">
            Frequently Asked <span className="text-[#1F1B18]">Questions</span>
          </h2>
          <p className="text-base sm:text-lg text-[#736B66] font-medium">
            Everything you need to know about our web design process and services.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className={`border rounded-2xl overflow-hidden transition-colors duration-300 ${isOpen ? 'bg-white border-[#C9A15A] shadow-sm' : 'bg-[#F0EAE0] border-[#E4DCCB] hover:border-[#C9A15A]/50'}`}
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full text-left px-6 py-6 flex items-center justify-between focus:outline-none"
                  aria-expanded={isOpen}
                >
                  <span className="text-base sm:text-lg font-bold text-[#1F1B18] pr-8">
                    {faq.question}
                  </span>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-colors duration-300 ${isOpen ? 'bg-[#C9A15A] text-white' : 'bg-white/50 text-[#C9A15A]'}`}>
                    {isOpen ? <Minus className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                  </div>
                </button>
                
                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: "easeInOut" }}
                    >
                      <div className="px-6 pb-6 pt-0 text-[#5A5450] font-medium leading-relaxed">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
