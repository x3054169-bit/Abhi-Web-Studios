import { motion } from "motion/react";
import { ExternalLink, ArrowRight } from "lucide-react";

export function Portfolio() {
  const projects = [
    {
      title: "Dental Designs",
      industry: "Medical",
      goal: "Bookings",
      image: "https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=600&h=400",
      description: "Redesigned booking flow → 40% increase in monthly appointments.",
      source: "— per client-reported bookings",
      link: "https://dental-designs-enpm.vercel.app/"
    },
    {
      title: "Zumba Gym",
      industry: "Fitness",
      goal: "Leads",
      image: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?auto=format&fit=crop&q=80&w=600&h=400",
      description: "High-performance landing page → doubled membership inquiries in 30 days.",
      source: "— Google Analytics",
      link: "https://zumba-gym.netlify.app/"
    },
    {
      title: "Sahu Real Estate",
      industry: "Real Estate",
      goal: "Leads",
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=600&h=400",
      description: "Fast property search → improved user retention and lead capture.",
      source: "— CRM Lead Data",
      link: "https://www.sahurealestate.com/"
    },
    {
      title: "Whiz Spa",
      industry: "Wellness",
      goal: "Sales",
      image: "https://images.unsplash.com/photo-1600334129128-685c5582fd35?auto=format&fit=crop&q=80&w=600&h=400",
      description: "Premium redesign → increased high-ticket service bookings by 25%.",
      source: "— Client Sales Report",
      link: "https://whizspa.in/"
    },
    {
      title: "Zenith Yoga Studio",
      industry: "Fitness",
      goal: "Sign-ups",
      image: "https://images.unsplash.com/photo-1599901860904-17e6ed7083a0?auto=format&fit=crop&q=80&w=600&h=400",
      description: "Optimized mobile experience → 60% boost in trial class registrations.",
      source: "— Booking System Data",
      link: "#"
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
  };

  return (
    <section id="work" className="py-16 md:py-24 lg:py-32 relative overflow-hidden bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 md:mb-24 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-foreground tracking-tighter leading-[1.1]">
              Our <span className="text-[#1F1B18]">Portfolio</span> of Success.
            </h2>
          </div>
          <div className="max-w-sm">
            <p className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed font-medium mb-4">
              Explore our proven track record of delivering high-performing websites for clinics, gyms, and local businesses in India. Each project is a showcase of our expertise in conversion-focused design.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed font-medium">
              We focus on building dental clinic website design and fitness landing pages that generate real leads and ROI for our clients.
            </p>
          </div>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-8"
        >
          {projects.map((project, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="group cursor-pointer bg-white border border-[#E4DCCB] rounded-2xl overflow-hidden flex flex-col hover:border-[var(--primary)] hover:-translate-y-1 transition-all duration-300 shadow-sm hover:shadow-md"
              onClick={() => project.link && project.link !== "#" && window.open(project.link, "_blank")}
            >
              <div className="relative aspect-[16/10] overflow-hidden border-b border-[#E4DCCB]">
                <img
                  src={project.image}
                  alt={`${project.title} - ${project.industry} Website Design by Abhi Web Studios`}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute top-4 left-4 flex gap-2">
                  <span className="text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 bg-black/60 backdrop-blur-md rounded-full border border-white/20">{project.industry}</span>
                </div>
              </div>
              <div className="p-6 flex flex-col flex-grow">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-foreground font-bold text-xl group-hover:text-[var(--primary)] transition-colors tracking-tight">{project.title}</h4>
                  {project.link && project.link !== "#" && <ExternalLink className="w-4 h-4 text-muted-foreground group-hover:text-[var(--primary)] transition-colors" />}
                </div>
                <p className="text-foreground text-sm leading-relaxed font-medium mb-1">{project.description}</p>
                <p className="text-xs text-muted-foreground italic mb-6">{project.source}</p>
                <div className="mt-auto flex items-center text-[11px] font-bold text-[var(--primary)] uppercase tracking-[0.2em] group-hover:gap-2 transition-all">
                  View Project
                  <ExternalLink className="ml-1 w-3 h-3" />
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-20 text-center"
        >
          <p className="text-muted-foreground font-medium mb-8">
            Want results like these for your business?
          </p>
          <a 
            href="#contact" 
            className="inline-flex items-center gap-2 group text-xl font-black text-foreground hover:text-[var(--primary)] transition-colors tracking-tighter"
          >
            Start your project today
            <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
