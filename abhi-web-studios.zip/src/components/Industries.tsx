import { motion } from "motion/react";
import { Stethoscope, Dumbbell, Home, Store, CheckCircle2 } from "lucide-react";

const audiences = [
  {
    title: "Dental Clinics",
    description: "Automated booking systems and professional patient-focused designs.",
    icon: <Stethoscope className="w-6 h-6 text-[var(--primary)]" />,
    link: "/services.html#dental-clinics"
  },
  {
    title: "Gyms & Fitness",
    description: "High-energy landing pages built to drive memberships and class signups.",
    icon: <Dumbbell className="w-6 h-6 text-[var(--primary)]" />,
    link: "/services.html#gyms"
  },
  {
    title: "Real Estate",
    description: "Fast property listings and lead capture forms for agents and agencies.",
    icon: <Home className="w-6 h-6 text-[var(--primary)]" />,
    link: "/services.html#real-estate"
  },
  {
    title: "Beauty Salon / Spa",
    description: "Google-optimized websites for Beauty salon / Spa's.",
    icon: <Store className="w-6 h-6 text-[var(--primary)]" />,
    link: "/services.html#salons"
  }
];

export function Industries() {
  return (
    <section className="py-16 md:py-24 bg-[var(--background-alt)] border-y border-border relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="text-center mb-12 md:mb-20">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-foreground tracking-tighter mb-6">
            Websites for <span className="text-[#1F1B18]">Salons, Spas & Clinics.</span>
          </h2>
          <p className="text-base sm:text-base text-muted-foreground max-w-2xl mx-auto font-medium mb-6">
            We don't try to be everything to everyone. We specialize in industries where we know we can deliver massive ROI through expert web developer services for gyms and high-end dental website design India.
          </p>
          <a href="/services.html" className="text-[var(--primary)] font-bold text-xs uppercase tracking-widest hover:text-[var(--primary-hover)] transition-colors">
            Explore our specific solutions →
          </a>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {audiences.map((item, index) => (
            <motion.a
              href={item.link}
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="block p-6 md:p-8 rounded-2xl bg-background border border-border hover:border-[var(--primary)] hover:-translate-y-1 hover:shadow-lg transition-all group"
            >
              <div className="w-12 h-12 rounded-xl bg-[var(--background-alt)] border border-border flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                {item.icon}
              </div>
              <h4 className="text-xl font-bold text-foreground mb-3 tracking-tight">{item.title}</h4>
              <p className="text-base sm:text-sm text-muted-foreground leading-relaxed font-medium mb-6">
                {item.description}
              </p>
              <div className="flex items-center gap-2 text-[10px] font-bold text-[var(--primary)] uppercase tracking-widest">
                <CheckCircle2 className="w-3 h-3" />
                Specialized Solution
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
