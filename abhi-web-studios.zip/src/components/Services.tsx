import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Layout, Palette, Target, MapPin, Search, Wrench, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

export function Services() {
  const services = [
    {
      title: "Business Websites",
      description: "Custom, mobile-first websites designed to establish authority and drive local inquiries.",
      icon: Layout,
    },
    {
      title: "Website Redesigns",
      description: "Transform outdated sites into modern, high-converting digital assets.",
      icon: Palette,
    },
    {
      title: "Landing Pages",
      description: "Highly focused, persuasive pages designed specifically for paid ad campaigns.",
      icon: Target,
    },
    {
      title: "GBP Optimization",
      description: "Optimize your Google Business Profile to dominate local map pack rankings.",
      icon: MapPin,
    },
    {
      title: "Local SEO",
      description: "Strategic on-page and technical SEO to improve your organic local search visibility.",
      icon: Search,
    },
    {
      title: "Maintenance & Hosting",
      description: "Fast, secure hosting with ongoing updates and technical support.",
      icon: Wrench,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
        ease: "easeOut",
      },
    },
  };

  return (
    <section id="services" className="py-16 md:py-24 lg:py-32 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="text-center max-w-4xl mx-auto mb-16 md:mb-24">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-foreground tracking-tighter mb-6">
            Website Design <span className="text-[#1F1B18]">Services</span> for Results.
          </h2>
          <p className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed font-medium mb-6">
            At Abhi Web Studios, we offer comprehensive web development and digital marketing services specifically tailored for clinics, gym owners, and local business providers. Our goal is to create a seamless bridge between your services and your future clients through strategic dental website design and technical SEO.
          </p>
          <p className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed font-medium">
            From technical SEO audits to advanced UI/UX optimization, we ensure your website is not just a digital business card, but a high-converting growth engine.
          </p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-8"
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="h-full"
            >
              <Card className="p-5 md:p-6 rounded-2xl bg-black/5 border border-border hover:border-[var(--primary)] transition-all duration-500 group cursor-default h-full relative overflow-hidden hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(201,161,90,0.1)]">
                <div className="absolute top-0 right-0 w-32 h-32 bg-[var(--primary)]/5 blur-3xl rounded-full -mr-16 -mt-16 group-hover:bg-[var(--primary)]/10 transition-colors" />
                <div className="relative z-10">
                  <div className="w-12 h-12 rounded-xl bg-black/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500 border border-border">
                    <service.icon className="w-6 h-6 text-[var(--primary)]" />
                  </div>
                  <h4 className="text-xl font-bold text-foreground mb-3 tracking-tight">
                    {service.title}
                  </h4>
                  <p className="text-muted-foreground leading-relaxed font-medium text-sm">
                    {service.description}
                  </p>
                </div>
              </Card>
            </motion.div>
          ))}
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <a 
            href="/services.html#services" 
            className="inline-flex items-center gap-2 text-[var(--primary)] font-bold text-base hover:text-[var(--primary-hover)] transition-colors group"
          >
            View all services
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}
