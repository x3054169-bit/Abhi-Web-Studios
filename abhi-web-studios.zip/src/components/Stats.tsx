import { motion } from "motion/react";

export function Stats() {
  const stats = [
    { value: "Mobile-first Design" },
    { value: "Fast Load Times" },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5,
      },
    },
  };

  return (
    <section className="py-12 md:py-16 bg-background relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12 relative z-10">
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="flex flex-col sm:flex-row justify-center gap-4 md:gap-8 text-center"
        >
          {stats.map((stat, index) => (
            <motion.div 
              key={index} 
              variants={itemVariants}
              className="px-8 py-6 rounded-2xl bg-[#F0EAE0] flex items-center justify-center border border-[#E4DCCB] shadow-sm flex-1"
            >
              <span className="text-xl sm:text-2xl font-black text-[#1F1B18] tracking-tight">
                {stat.value}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
