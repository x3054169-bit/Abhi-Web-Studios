import { LineChart, Line, ResponsiveContainer } from "recharts";

const chartData = [
  { value: 40 }, { value: 35 }, { value: 55 }, { value: 45 }, 
  { value: 70 }, { value: 65 }, { value: 85 }, { value: 75 }, 
  { value: 95 }, { value: 90 }, { value: 110 }
];

export default function HeroChart() {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={chartData}>
        <Line 
          type="monotone" 
          dataKey="value" 
          stroke="#C9A15A" 
          strokeWidth={3} 
          dot={false}
          animationDuration={2000}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
