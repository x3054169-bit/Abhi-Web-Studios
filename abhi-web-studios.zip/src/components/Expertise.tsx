import { motion } from "motion/react";
import { Code2, Palette, Rocket, Search } from "lucide-react";

const expertiseItems = [
  {
    title: "Custom Business Websites",
    description: "Fast, secure, and mobile-responsive websites tailored to your specific business needs. Designed to load instantly and keep visitors engaged.",
    icon: Code2,
    image: "https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&q=80&w=800&h=500",
  },
  {
    title: "Conversion-Focused Design",
    description: "Clean, professional layouts that guide your visitors effortlessly toward booking an appointment or making a call.",
    icon: Palette,
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&q=80&w=800&h=500",
  },
  {
    title: "Lead Generation Strategy",
    description: "Strategic call-to-actions, contact forms, and WhatsApp integrations placed exactly where your customers are ready to buy.",
    icon: Rocket,
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800&h=500",
  },
  {
    title: "Local SEO & Visibility",
    description: "Outrank your local competitors on Google. We optimize your site structure, speed, and content to attract high-intent local traffic.",
    icon: Search,
    image: "https://images.unsplash.com/photo-1512428559087-560fa5ceab42?auto=format&fit=crop&q=80&w=800&h=500",
  }
];

export function Expertise() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1],
      },
    },
  };

  return (
    <section id="expertise" className="py-16 md:py-24 lg:py-32 relative overflow-hidden bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 md:mb-24">
          <div className="max-w-2xl">
            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black text-foreground tracking-tighter leading-[1.1]"
            >
              Websites engineered to bring your business <span className="text-[#1F1B18]">more customers.</span>
            </motion.h2>
          </div>
            <div className="max-w-sm">
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed font-medium mb-4"
              >
                We build fast, mobile-first websites for local and service businesses — from clinics and salons to gyms and real estate. Every site is designed around one goal: turning visitors into real inquiries, not just traffic.
              </motion.p>
              <a href="#contact" className="text-[var(--primary)] font-bold text-xs uppercase tracking-widest hover:text-[var(--primary-hover)] transition-colors">
                Book a Strategy Session →
              </a>
            </div>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6"
        >
          {expertiseItems.map((item, index) => (
            <motion.div 
              key={index} 
              variants={itemVariants}
              className="group flex flex-col p-5 md:p-6 rounded-2xl bg-[#FDFBF7] border border-[#E4DCCB] hover:border-[var(--primary)] transition-all duration-300 shadow-sm hover:shadow-md"
            >
              <div className="w-12 h-12 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center mb-5 border border-[var(--primary)]/20 flex-shrink-0 transition-transform duration-500 group-hover:scale-110">
                <item.icon className="w-6 h-6 text-[var(--primary)]" />
              </div>
              <h3 className="text-lg md:text-xl font-bold text-[#1F1B18] mb-2 group-hover:text-[var(--primary)] transition-colors tracking-tight">
                {item.title}
              </h3>
              <p className="text-[#5A5450] text-sm leading-relaxed mb-6 font-medium">
                {item.description}
              </p>
              <div className="mt-auto relative rounded-xl overflow-hidden aspect-[16/10] border border-[#E4DCCB]">
                <img 
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
