import { motion } from "motion/react";
import { Check, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";

const pricingTiers = [
  {
    name: "Starter",
    price: "₹8,000–15,000",
    description: "Perfect for new local businesses establishing their online presence.",
    features: [
      "One-page site",
      "WhatsApp button",
      "Contact form",
      "Google Maps integration",
      "Mobile responsive"
    ],
    highlighted: false,
    whatsappMsg: "I'm interested in the Starter package"
  },
  {
    name: "Growth",
    price: "₹20,000–35,000",
    description: "Comprehensive website to capture leads and build authority.",
    features: [
      "Multi-page site",
      "SEO setup",
      "Blog functionality",
      "Testimonials section",
      "Speed optimization",
      "Google Analytics"
    ],
    highlighted: true,
    tag: "Most Popular",
    whatsappMsg: "I'm interested in the Growth package"
  },
  {
    name: "Premium",
    price: "₹40,000+",
    description: "Advanced solutions for scaling businesses and high-traffic clinics.",
    features: [
      "Custom design",
      "Booking system",
      "CRM integration",
      "AI chatbot",
      "Advanced SEO",
      "Ongoing maintenance"
    ],
    highlighted: false,
    whatsappMsg: "I'm interested in the Premium package"
  }
];

export function Pricing() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut",
      },
    },
  };

  return (
    <section id="pricing" className="py-16 md:py-24 lg:py-32 relative bg-background overflow-hidden border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="text-center max-w-3xl mx-auto mb-16 md:mb-24">
          <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-foreground tracking-tighter mb-6">
            Simple, Transparent <span className="text-[#1F1B18]">Pricing.</span>
          </h2>
          <p className="text-base sm:text-lg text-muted-foreground leading-relaxed font-medium">
            Choose the perfect website package for your business goals. No hidden fees, just results.
          </p>
        </div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start"
        >
          {pricingTiers.map((tier, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className={`relative flex flex-col h-full rounded-3xl p-8 ${
                tier.highlighted 
                  ? 'bg-background border-2 border-[var(--primary)] shadow-[0_0_40px_rgba(201,161,90,0.15)] md:-mt-4 md:mb-4' 
                  : 'bg-black/5 border border-border'
              }`}
            >
              {tier.highlighted && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-[var(--primary)] text-white px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest shadow-lg">
                  {tier.tag}
                </div>
              )}
              
              <div className="mb-8">
                <h3 className="text-2xl font-bold text-foreground mb-2">{tier.name}</h3>
                <div className="text-[var(--primary)] font-black text-3xl sm:text-4xl tracking-tighter mb-4">
                  {tier.price}
                </div>
                <p className="text-muted-foreground text-sm font-medium leading-relaxed">
                  {tier.description}
                </p>
              </div>

              <div className="flex-grow">
                <ul className="space-y-4 mb-8">
                  {tier.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm font-medium text-foreground">
                      <div className="w-5 h-5 rounded-full bg-[var(--primary)]/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Check className="w-3 h-3 text-[var(--primary)]" />
                      </div>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <Button
                render={<a href={`https://wa.me/918871694891?text=${encodeURIComponent(tier.whatsappMsg)}`} target="_blank" rel="noopener noreferrer" />}
                nativeButton={false}
                className={`w-full h-14 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-[0.98] ${
                  tier.highlighted
                    ? 'bg-[#25D366] hover:bg-[#1DA851] text-white shadow-lg'
                    : 'bg-black/10 hover:bg-[#25D366] text-foreground hover:text-white border border-border hover:border-[#1DA851]'
                }`}
              >
                <MessageSquare className="w-5 h-5" />
                Inquire via WhatsApp
              </Button>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
