import { Button } from "@/components/ui/button.tsx";
import { motion, useScroll, useTransform, AnimatePresence } from "motion/react";
import { ArrowRight, Zap, TrendingUp, Users, CheckCircle2, Globe, MousePointer2 } from "lucide-react";
import { useRef, useState, useEffect, lazy, Suspense } from "react";



const recentLeads = [
  { id: 1, name: "Sarah J.", action: "Booked Consultation", time: "2m ago", amount: "$1,200" },
  { id: 2, name: "Mark R.", action: "Signed Contract", time: "5m ago", amount: "$3,500" },
  { id: 3, name: "Dental Clinic", action: "New Inquiry", time: "12m ago", amount: "High Value" },
];

export function Hero() {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeLeadIndex, setActiveLeadIndex] = useState(0);
  
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"],
  });

  const y1 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -150]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  useEffect(() => {
    const rotateLeads = () => {
      setActiveLeadIndex((prev) => (prev + 1) % recentLeads.length);
    };

    const interval = setInterval(() => {
      if ('requestIdleCallback' in window) {
        window.requestIdleCallback(rotateLeads);
      } else {
        setTimeout(rotateLeads, 0);
      }
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section ref={containerRef} className="relative min-h-screen flex flex-col justify-center overflow-hidden py-16 md:py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="flex flex-col items-center text-center md:items-start md:text-left"
            style={{ y: y1 }}
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FDFBF7] border border-[#C9A15A] mb-6 md:mb-8 shadow-sm">
              <span className="text-[10px] font-bold text-[#1F1B18] uppercase tracking-[0.2em]">
                0.8s load time · mobile-first
              </span>
            </div>
            <h1 className="text-3xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-foreground leading-[1.1] tracking-tighter mb-6 md:mb-8">
              Websites that turn visitors into customers — <br />
              <span className="text-[#1F1B18]">for local & service businesses.</span>
            </h1>
            <p className="text-base sm:text-base md:text-lg text-muted-foreground max-w-lg mb-8 md:mb-12 leading-relaxed font-medium">
              Fast, mobile-first websites designed to turn visitors into real inquiries.
            </p>
            <div className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto mb-8">
              <Button 
                render={<a href="https://wa.me/918871694891?text=Hi,%20I%20want%20a%20website%20for%20my%20business" target="_blank" rel="noopener noreferrer" />}
                nativeButton={false}
                size="lg" 
                className="w-full sm:flex-1 bg-[#25D366] hover:bg-[#1DA851] text-white border-none h-14 sm:h-16 px-8 sm:px-10 text-base sm:text-lg font-bold rounded-2xl"
              >
                Chat on WhatsApp
              </Button>
              <Button 
                render={<a href="#contact" />}
                nativeButton={false}
                size="lg" 
                className="w-full sm:flex-1 border-none bg-[#1F1B18] hover:bg-[#2A2520] text-[#FDFBF7] h-14 sm:h-16 px-8 sm:px-10 text-base sm:text-lg font-bold rounded-2xl"
              >
                Get Free Website Audit
              </Button>
            </div>
          </motion.div>

          <div
            className="relative h-[500px] perspective-2000 mt-12 lg:mt-0 hidden lg:block"
            style={{ 
              transform: `translateY(${scrollYProgress.get() * -100}px)`,
              transition: 'transform 0.1s linear'
            }}
          >
            {/* Main Browser Window - Simplified */}
            <div
              className="absolute top-0 right-0 w-[85%] aspect-[16/10] bg-background/50 backdrop-blur-2xl rounded-3xl border border-border shadow-2xl z-30 overflow-hidden"
              style={{ transform: 'rotateX(10deg) rotateY(-10deg)' }}
            >
              {/* Browser Header */}
              <div className="h-8 bg-black/5 border-b border-border flex items-center px-4 gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-black/20" />
                <div className="w-1.5 h-1.5 rounded-full bg-black/20" />
                <div className="w-1.5 h-1.5 rounded-full bg-black/20" />
              </div>
              
              <div className="relative w-full h-full">
                <img 
                  src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=60&w=800&fm=webp" 
                  alt="Website Design for Clinics and Gyms - Abhi Web Studios Preview" 
                  className="w-full h-full object-cover opacity-80"
                  referrerPolicy="no-referrer"
                  fetchPriority="high"
                />
              </div>
            </div>

            {/* Performance Badge */}
            <div
              className="absolute top-20 left-0 bg-background/90 backdrop-blur-3xl rounded-3xl p-6 border border-border shadow-2xl z-40 flex items-center gap-4"
              style={{ transform: 'scale(0.9) rotateX(10deg) rotateY(-10deg)' }}
            >
              <div className="w-12 h-12 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center border border-[var(--primary)]/20">
                <Zap className="w-6 h-6 text-[var(--primary)]" />
              </div>
              <div>
                <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1">Performance</p>
                <p className="text-2xl font-black text-foreground tracking-tighter">Built for speed</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
