import { motion } from "motion/react";
import { Award, Target, Zap } from "lucide-react";

export function About() {
  return (
    <section id="about" className="py-16 md:py-24 lg:py-32 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-[var(--primary)]/5 blur-[120px] rounded-full -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-foreground tracking-tighter mb-6 md:mb-8 leading-[1.1]">
              About <span className="text-[#1F1B18]">Abhi Web Studios</span>.
            </h2>
            <p className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed mb-6 md:mb-8 font-medium">
              Abhi Web Studios is a boutique digital engineering agency focused on one thing: building websites that actually bring you clients. Every design decision, layout, and feature is built around conversion — not just looks.
            </p>
            <p className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed mb-10 md:mb-12 font-medium">
              We don't just build websites; we engineer high-converting digital assets that serve as your 24/7 sales team. Our approach combines high-end design with conversion psychology to turn visitors into revenue.
            </p>
            
            <div className="flex flex-wrap gap-8">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center border border-[var(--primary)]/30">
                  <Target className="w-5 h-5 text-[var(--primary)]" />
                </div>
                <div>
                  <p className="text-foreground font-bold text-sm">Conversion First</p>
                  <p className="text-muted-foreground text-[10px] uppercase font-bold tracking-widest">Our Core Philosophy</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[var(--primary)]/10 flex items-center justify-center border border-[var(--primary)]/30">
                  <Zap className="w-5 h-5 text-[var(--primary)]" />
                </div>
                <div>
                  <p className="text-foreground font-bold text-sm">High Performance</p>
                  <p className="text-muted-foreground text-[10px] uppercase font-bold tracking-widest">0.8s Load Times</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative h-full"
          >
            <div className="h-full min-h-[500px] rounded-3xl overflow-hidden bg-[#F0EAE0] border border-[#E4DCCB] flex flex-col group shadow-sm">
              <div className="flex-1 relative overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1556157382-97eda2d62296?auto=format&fit=crop&q=80&w=800&h=800" 
                  alt="Abhinav Tripathi" 
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#F0EAE0] via-transparent to-transparent opacity-60" />
              </div>
              <div className="px-8 pb-8 pt-4 text-center relative z-10">
                <h4 className="text-2xl font-black text-[#1F1B18] tracking-tighter mb-1 uppercase">Abhinav Tripathi</h4>
                <p className="text-[#736B66] font-bold text-[10px] uppercase tracking-[0.2em] mb-4">Founder & Lead Strategist</p>
                <div className="w-12 h-1 bg-[var(--primary)] rounded-full mx-auto mb-6" />
                <p className="text-[#1F1B18] text-sm font-semibold leading-relaxed italic">
                  "I've built 37+ sites for local businesses — most of what I do now is make sure yours doesn't look like everyone else's."
                </p>
              </div>
            </div>
            
            {/* Decorative Elements */}
            <div className="absolute -top-6 -right-6 w-24 h-24 bg-[var(--primary)]/20 blur-3xl rounded-full -z-10" />
            <div className="absolute -bottom-6 -left-6 w-24 h-24 bg-[var(--primary)]/20 blur-3xl rounded-full -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
