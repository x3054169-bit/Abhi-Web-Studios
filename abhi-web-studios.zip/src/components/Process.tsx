import { motion } from "motion/react";

export function Process() {
  const steps = [
    {
      title: "Audit",
      description: "Analyze your current site and competitors",
    },
    {
      title: "Plan",
      description: "Create strategy and layout",
    },
    {
      title: "Build",
      description: "Develop fast, clean website",
    },
    {
      title: "Launch",
      description: "Deploy and optimize for leads",
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut",
      },
    },
  };

  return (
    <section id="process" className="py-16 md:py-24 lg:py-32 bg-[var(--background-alt)] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 lg:px-12">
        <div className="text-center max-w-4xl mx-auto mb-16 md:mb-24">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-foreground tracking-tighter mb-6"
          >
            Our <span className="text-[#1F1B18]">Process</span> to Results.
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-base sm:text-base md:text-lg text-muted-foreground leading-relaxed font-medium"
          >
            We follow a streamlined 4-step workflow to ensure your website design for clinics or gyms is delivered on time and optimized for maximum lead generation.
          </motion.p>
        </div>

        <div className="relative">
          {/* Horizontal Connector Line for md and up */}
          <div className="hidden md:block absolute top-[24px] left-[10%] right-[10%] h-px bg-[var(--primary)] z-0" />
          {/* Vertical Connector Line for mobile */}
          <div className="block md:hidden absolute top-[24px] bottom-[24px] left-[24px] w-px bg-[var(--primary)] z-0" />

          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            className="flex flex-col md:flex-row justify-between gap-12 md:gap-4 relative z-10"
          >
            {steps.map((step, index) => (
              <motion.div 
                key={index} 
                variants={itemVariants}
                className="flex flex-row md:flex-col items-start md:items-center text-left md:text-center group relative flex-1 px-0 md:px-4"
              >
                <div className="w-12 h-12 rounded-full bg-[var(--primary)] ring-[8px] ring-[var(--background-alt)] flex flex-shrink-0 items-center justify-center z-10 mb-0 md:mb-6 mr-6 md:mr-0 transition-transform duration-300 group-hover:scale-110">
                  <span className="text-[#1F1B18] font-black text-xl">{index + 1}</span>
                </div>
                
                <div className="pt-2 md:pt-0">
                  <h4 className="text-xl font-bold text-foreground mb-2 tracking-tight">{step.title}</h4>
                  <p className="text-muted-foreground text-sm leading-relaxed font-medium">
                    {step.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}
