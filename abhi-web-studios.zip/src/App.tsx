import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import React, { Suspense, lazy } from "react";

const Stats = lazy(() => import("@/components/Stats").then(m => ({ default: m.Stats })));
const Services = lazy(() => import("@/components/Services").then(m => ({ default: m.Services })));
const Expertise = lazy(() => import("@/components/Expertise").then(m => ({ default: m.Expertise })));
const Industries = lazy(() => import("@/components/Industries").then(m => ({ default: m.Industries })));
const Pricing = lazy(() => import("@/components/Pricing").then(m => ({ default: m.Pricing })));
const Portfolio = lazy(() => import("@/components/Portfolio").then(m => ({ default: m.Portfolio })));
const Process = lazy(() => import("@/components/Process").then(m => ({ default: m.Process })));
const About = lazy(() => import("@/components/About").then(m => ({ default: m.About })));
const FAQ = lazy(() => import("@/components/FAQ").then(m => ({ default: m.FAQ })));
const CTA = lazy(() => import("@/components/CTA").then(m => ({ default: m.CTA })));
const Contact = lazy(() => import("@/components/Contact").then(m => ({ default: m.Contact })));
const Footer = lazy(() => import("@/components/Footer").then(m => ({ default: m.Footer })));
const SmoothScroll = lazy(() => import("@/components/SmoothScroll").then(m => ({ default: m.SmoothScroll })));
const ScrollProgress = lazy(() => import("@/components/ScrollProgress").then(m => ({ default: m.ScrollProgress })));
const MobileActions = lazy(() => import("@/components/MobileActions").then(m => ({ default: m.MobileActions })));

export default function App() {
  return (
    <div className="min-h-screen bg-background text-foreground relative overflow-x-hidden">
      <Suspense fallback={null}>
        <SmoothScroll />
        <ScrollProgress />
        <MobileActions />
      </Suspense>

      <Navbar />
      <main className="relative">
        <Hero />
        <Suspense fallback={<div className="h-64" />}>
          <Stats />
        </Suspense>
        <Suspense fallback={<div className="h-[2000px]" />}>
          <div className="relative">
            <Services />
            <Expertise />
            <Industries />
            <Pricing />
            <Portfolio />
            <Process />
            <About />
            <FAQ />
            <CTA />
            <Contact />
          </div>
        </Suspense>
      </main>
      <Suspense fallback={<div className="h-48" />}>
        <Footer />
      </Suspense>
    </div>
  );
}
