const fs = require('fs');
const path = require('path');

const dir = './src/components';
const files = fs.readdirSync(dir).filter(f => f.endsWith('.tsx'));

const replacements = [
  { from: /text-white\/70/g, to: 'text-muted-foreground' },
  { from: /text-white\/60/g, to: 'text-muted-foreground' },
  { from: /text-white\/50/g, to: 'text-muted-foreground' },
  { from: /text-white\/40/g, to: 'text-muted-foreground' },
  { from: /text-white\/30/g, to: 'text-muted-foreground' },
  { from: /text-white/g, to: 'text-foreground' },
  
  { from: /bg-white\/5/g, to: 'bg-black/5' },
  { from: /bg-white\/10/g, to: 'bg-black/10' },
  { from: /bg-white\/20/g, to: 'bg-black/20' },
  { from: /border-white\/5/g, to: 'border-border' },
  { from: /border-white\/10/g, to: 'border-border' },
  { from: /border-white\/20/g, to: 'border-border' },
  { from: /border-white\/\[0\.05\]/g, to: 'border-border' },

  { from: /text-blue-500/g, to: 'text-[var(--primary)]' },
  { from: /text-blue-400/g, to: 'text-[var(--primary)]' },
  { from: /text-purple-500/g, to: 'text-[var(--primary)]' },
  { from: /text-purple-400/g, to: 'text-[var(--primary)]' },
  { from: /text-orange-500/g, to: 'text-[var(--primary)]' },
  // Keep green text for success messages? Actually let's manually fix Contact.tsx later if needed, but let's only do blue/purple/orange for now.

  { from: /border-blue-500\/[0-9]+/g, to: 'border-[var(--primary)]/30' },
  { from: /border-purple-500\/[0-9]+/g, to: 'border-[var(--primary)]/30' },
  { from: /border-orange-500\/[0-9]+/g, to: 'border-[var(--primary)]/30' },

  { from: /bg-blue-500\/10/g, to: 'bg-[var(--primary)]/10' },
  { from: /bg-purple-500\/10/g, to: 'bg-[var(--primary)]/10' },
  { from: /bg-orange-500\/10/g, to: 'bg-[var(--primary)]/10' },
  
  { from: /bg-blue-500/g, to: 'bg-[var(--primary)]' },
  { from: /bg-blue-600/g, to: 'bg-[var(--primary)]' },
  { from: /bg-blue-700/g, to: 'bg-[var(--primary-hover)]' },
  
  { from: /shadow-\[0_0_30px_rgba\(59,130,246,0\.1\)\]/g, to: 'shadow-[0_0_30px_rgba(201,161,90,0.1)]' },
  { from: /shadow-\[0_0_30px_rgba\(37,99,235,0\.2\)\]/g, to: 'shadow-[0_0_30px_rgba(201,161,90,0.2)]' },
  { from: /shadow-\[0_0_30px_rgba\(37,99,235,0\.3\)\]/g, to: 'shadow-[0_0_30px_rgba(201,161,90,0.3)]' },

  { from: /bg-gradient-to-br from-blue-500 to-purple-600/g, to: 'bg-[var(--primary)]' },
  { from: /bg-gradient-to-br from-blue-600 to-purple-700/g, to: 'bg-[var(--primary)]' },
  { from: /bg-gradient-to-r from-blue-600 to-purple-600/g, to: 'bg-[var(--primary)]' },
  { from: /bg-gradient-to-b from-blue-500\/\[0\.02\] to-transparent/g, to: 'bg-transparent' },

  { from: /glow-blue/g, to: '' },
  { from: /shadow-blue-500\/20/g, to: 'shadow-[var(--primary)]/20' },

  { from: /bg-white\/\[0\.02\]/g, to: 'bg-[var(--background-alt)]' },
  { from: /bg-white\/\[0\.03\]/g, to: 'bg-[var(--background-alt)]' },
  { from: /bg-black/g, to: 'bg-background' },
];

files.forEach(file => {
  if (['Hero.tsx', 'Stats.tsx', 'Services.tsx', 'Expertise.tsx', 'Navbar.tsx'].includes(file)) return;
  let content = fs.readFileSync(path.join(dir, file), 'utf8');
  let newContent = content;
  replacements.forEach(r => {
    newContent = newContent.replace(r.from, r.to);
  });
  // Also remove decorative glow orbs if any
  newContent = newContent.replace(/<div className="absolute[^>]*bg-blue-600\/\[?0\.[0-9]+\]?[^>]*\/>/g, '');
  newContent = newContent.replace(/<div className="absolute[^>]*bg-purple-600\/\[?0\.[0-9]+\]?[^>]*\/>/g, '');

  if (newContent !== content) {
    fs.writeFileSync(path.join(dir, file), newContent);
    console.log(`Updated ${file}`);
  }
});
