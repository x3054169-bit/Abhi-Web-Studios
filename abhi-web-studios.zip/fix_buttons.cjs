const fs = require('fs');
const path = require('path');

const dir = './src/components';
const files = ['Contact.tsx', 'CTA.tsx', 'Footer.tsx', 'About.tsx', 'Process.tsx', 'Portfolio.tsx', 'Industries.tsx', 'MobileActions.tsx'];

files.forEach(file => {
  let content = fs.readFileSync(path.join(dir, file), 'utf8');
  let newContent = content;
  
  // For Contact.tsx WhatsApp button
  newContent = newContent.replace(/className="w-full sm:w-auto px-8 py-6 text-lg font-bold bg-green-600 hover:bg-green-500 text-foreground/g, 'className="w-full sm:w-auto px-8 py-6 text-lg font-bold bg-[#25D366] hover:bg-[#1DA851] text-white');
  
  // For submit buttons
  newContent = newContent.replace(/className="w-full py-6 text-lg font-bold bg-\[var\(--primary\)\] hover:bg-\[var\(--primary-hover\)\] text-foreground/g, 'className="w-full py-6 text-lg font-bold bg-[var(--primary)] hover:bg-[var(--primary-hover)] text-white');
  
  // For CTA buttons
  newContent = newContent.replace(/className="w-full sm:w-auto px-8 h-14 sm:h-16 text-base sm:text-lg font-bold bg-\[var\(--primary\)\] hover:bg-\[var\(--primary-hover\)\] text-foreground/g, 'className="w-full sm:w-auto px-8 h-14 sm:h-16 text-base sm:text-lg font-bold bg-[var(--primary)] hover:bg-[var(--primary-hover)] text-white');
  
  // Footer get free audit button
  newContent = newContent.replace(/className="bg-\[var\(--primary\)\] hover:bg-\[var\(--primary\)\] disabled:bg-\[var\(--primary\)\]\/50 text-foreground/g, 'className="bg-[var(--primary)] hover:bg-[var(--primary-hover)] disabled:bg-[var(--primary)]/50 text-white');

  // Copy email badge
  newContent = newContent.replace(/bg-\[var\(--primary\)\] text-foreground text-\[10px\]/g, 'bg-[var(--primary)] text-white text-[10px]');
  
  if (newContent !== content) {
    fs.writeFileSync(path.join(dir, file), newContent);
    console.log(`Fixed buttons in ${file}`);
  }
});
